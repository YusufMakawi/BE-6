<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AnimalController extends Controller
{
    public $hewan = [["id" => "kijang",],
                       ["id" => "kingkong",],
                       ["id" => "kangkung"]
                      ];

    

    public function index()
    {

    // silahkan pilih array private atau umum untuk nomer 1
    //     $animals = collect([
    //     [
    //         'id' => 'kijang',
    //     ],
    //     [
    //         'id' => 'kingkong',
    //     ],
    //     [
    //         'id' => 'kangkung',
    //     ],
        
    // ]);

    // return $animals->where('id');

        // PAGE 1 & 2 COCOK BUAT COLLECTION
        // $no = 1;
        // foreach($this->animals as $animal){
        //     echo $no++.'. '.$animal[id].'<br>';
       
        // };

        // foreach($this->animal as $this->kewan){
        //     #as digunakan untuk mengganti parameter animal menjadi kewan
        //     echo "$this->kewan" . PHP_EOL;
        //     echo "<br>";
        // }
        

        // echo "Menampilkan data animals : ";

        // PAGE INI COCOK UNTUK ARRAY UMUM
        foreach($this->hewan as $kewan){
			#as digunakan untuk mengganti parameter animal menjadi kewan
			echo "<br>". "$kewan[id]" . PHP_EOL;
			echo "<br>";
		}


    }

    public function store(Request $request)
    {
        // echo "Nama hewan: $request->nama";
        // echo "<br>";
        // echo "Menambahkan hewan baru";


        array_push($this->hewan, $request);
        $this->index();
        

    }

    public function update(Request $request, $id)
    {
        echo "Nama hewan: $request->nama";
        echo "<br>";
        echo "Mengupdate data hewan id $id";

        
        // $this->animals[$id] = $request;
        
        echo "Masih Bigung Kakak ...";


       
            // $request = $this->find($id);
            
            // // if (!$animals) {
            // //     return response()->json(['message' => 'Data not found'], 404);
            // // }
            
            // // $this->validate($request, [
            // //     "id" => "hewan update",
        
            // // ]);
    
            // $id = $request->all();
            // $this->index();

            // $animals->fill($data);
            // $animals->save();
    
            // return response()->json($animals);
      

    }

    public function destroy($id)
    {
        // echo "Menghapus data hewan id $id";

        // $animals = collect([
        //     "kijang","kingkong","kangkung"
        // ]);

        // dd($animals->take('2'));



        if(isset($this->animal[$id])) {
            return $this->index = array_splice($this->animal,  $id , 1);
        }
        
    }
}
