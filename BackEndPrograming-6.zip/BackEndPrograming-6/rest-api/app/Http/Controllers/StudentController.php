<?php

namespace App\Http\Controllers;

use App\Pelajar;
use Illuminate\Http\Request;
use Psy\CodeCleaner\EmptyArrayDimFetchPass;

class StudentController extends Controller
{
    //

    public function index()
    {
       $pelajars = Pelajar::all();


       if(!empty($Pelajars)){
           $response = 
           [
                'message' => 'semua data telah di posts',
                'data' => $pelajars,
           ];

           return response()->json(['posts' => $pelajars], 200, $response);
       
        }else{
           $response = [ 
                'message' => 'data tidak ada'
           ];

           return response()->json($response, 200);
       }

    //    echo $pelajars;
    }

    public function store(Request $request) 
	{


		$pelajars = Pelajar::create($request->all());

		$response = [
			'message' => 'Student is created succesfully',
			'data' => $pelajars,
		];

		return response()->json($response, 201);
	}

    public function update(Request $request, $id)
	{
    


        $pelajars = Pelajar::find($id);

        if ($pelajars) {
            $pelajars->update([
                'nama' => $request->nama ?? $pelajars->nama,
                'nim' => $request->nim ?? $pelajars->nim,
                'kelas' => $request->kelas ?? $pelajars->kelas,
                'email' => $request->email ?? $pelajars->email,
                'jurusan' => $request->jurusan ?? $pelajars->jurusan
            ]);

            $response = [
                'message' => 'data berhasil diupdate',
                'data' => $pelajars
            ];
            return response()->json($response, 200);
        } else {
            $response = [
                'message' => 'data tidak ditemukan',
            ];
            return response()->json($response, 404);
        }
	}

    
    public function destroy($id) 
	{

        $pelajars = Pelajar::find($id);

        if($pelajars){
            $pelajars->delete();
            
            $response = [
                'message' => 'data berhasil dihapus'
            ];

            return response()->json($response, 200);
        }else{
            $response = [
                'message' => 'data tidak ada'
            ];

            return response()->json($response, 404);
        }
        

        // $pelajars = Pelajar::find($id);
        // $pelajars->delete();
        // return "data dengan id " . $id . " dihapus";

		
	}

    public function show($id){

        $pelajars= Pelajar::find($id);


        if($pelajars){
            $response =[
                'message' => 'mendapatkan detail data',
                'data' => $pelajars
            ];

            return response()->json($response, 201);

        }else{
            $response = [
                'message' => 'data tidak ditemukan',
                'data' => $pelajars
            ];

            return response()->json($response, 404);
        }
    }
       


}
